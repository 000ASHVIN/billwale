<section class="about-section about-section-two px-md-5" id="work">
    <div class="container-fluid">
        <h3 class="title">HOW WE WORK</h3>
        <div class="mt-md-5 mt-0 row">
            <div class="mt-md-0 mt-5 col-md-4">
                <div class="single-about text-center">
                    <div class="about-bg-main">
                        <div class="about-bg"><img src="{{ asset('assets/images/home/tax.png') }}" alt=""></div>
                    </div>
                    <h3>What is Lorem Ipsum?</h3>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum
                        has been the industrys standard dummy text ever since the 1500s, when an unknown printer
                        took a galley of type and scrambled it to make a type specimen book.</p>
                </div>
            </div>
            <div class="mt-md-0 mt-5 col-md-4">
                <div class="single-about text-center">
                    <div class="about-bg-main">
                        <div class="about-bg"><img src="{{ asset('assets/images/home/tax.png') }}" alt=""></div>
                    </div>
                    <h3>What is Lorem Ipsum?</h3>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum
                        has been the industrys standard dummy text ever since the 1500s, when an unknown printer
                        took a galley of type and scrambled it to make a type specimen book.</p>
                </div>
            </div>
            <div class="mt-md-0 mt-5 col-md-4">
                <div class="single-about text-center">
                    <div class="about-bg-main">
                        <div class="about-bg"><img src="{{ asset('assets/images/home/tax.png') }}" alt=""></div>
                    </div>
                    <h3>What is Lorem Ipsum?</h3>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum
                        has been the industrys standard dummy text ever since the 1500s, when an unknown printer
                        took a galley of type and scrambled it to make a type specimen book.</p>
                </div>
            </div>
        </div>
    </div>
</section>