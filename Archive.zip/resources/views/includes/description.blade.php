<section class="details-page position-relative">
    <div class="bg-round"> </div>
    <div class="container">
        <div class="row">
            <div class="col-md-6"><img src="{{ asset('assets/images/home/computer.png') }}" alt="" class="w-100"></div>
            <div class="col-md-6">
                <div class="details-inner-section">
                    <h4>Contrary to popular belief, Lorem Ipsum is not simply random text</h4>
                    <p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those
                        interested. Sections 1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" by Cicero
                        are also reproduced in their exact original form, accompanied by English versions from
                        the 1914 translation by H. Rackham.</p><button class="inquiry-now mt-3">Inquiry
                        Now</button>
                </div>
            </div>
        </div>
    </div>
</section>