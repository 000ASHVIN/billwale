<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
        <li class="nav-item">
            <a class="nav-link" href="/admin">
                <i class="icon-grid menu-icon"></i>
                <span class="menu-title">Dashboard</span>
            </a>
        </li>
        
        <li class="nav-item">
            <a class="nav-link" href="/admin/inquiries">
                <i class="icon-paper menu-icon"></i>
                <span class="menu-title">Inquiries</span>
            </a>
        </li>
    </ul>
</nav><?php /**PATH /Users/solankiashvin/Desktop/Projects/Laravel/billwale/resources/views/admin/includes/sidebar.blade.php ENDPATH**/ ?>