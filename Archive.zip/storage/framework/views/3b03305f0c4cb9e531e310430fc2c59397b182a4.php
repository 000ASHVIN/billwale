<section class="details-page position-relative  px-md-5 px-0" id="feature">
    <div class="bg-round-2"> </div>
    <h3 class="title">App Features</h3>
    <div class="container-fluid">
        <div class="row">
            
            <div class="col-lg-4 col-md-6"><img src="<?php echo e(asset('assets/images/home/about2.png')); ?>" alt="" class="w-100 pt-5"></div>
            <div class="col-lg-4 col-md-6">
                <div class="details-inner-section">
                    <h4 class="mb-5">Contrary to popular belief, Lorem Ipsum is not simply random text</h4>
                    <div class="mt-2 d-flex"><img src="<?php echo e(asset('assets/images/home/check-number.png')); ?>" alt="" class="right-click">
                        <p class="mt-0 ml-2">Lorem Ipsum is simply dummy text of the printing and typesetting
                            industry. Lorem Ipsum has been the industrys standard dummy text ever since the
                            1500s.</p>
                    </div>
                    <div class="mt-2 d-flex"><img src="<?php echo e(asset('assets/images/home/check-number.png')); ?>" alt="" class="right-click">
                        <p class="mt-0 ml-2">Lorem Ipsum is simply dummy text of the printing and typesetting
                            industry. Lorem Ipsum has been the industrys standard dummy text ever since the
                            1500s.</p>
                    </div>
                    <div class="mt-2 d-flex"><img src="<?php echo e(asset('assets/images/home/check-number.png')); ?>" alt="" class="right-click">
                        <p class="mt-0 ml-2">Lorem Ipsum is simply dummy text of the printing and typesetting
                            industry. Lorem Ipsum has been the industrys standard dummy text ever since the
                            1500s.</p>
                    </div><button class="inquiry-now mt-3">Inquiry Now</button>
                </div>
            </div>

            <div class="col-lg-4 col-md-12">
                <div class="form-info">
                    <div class="inquiry-now-title row">
                        <div class="col-md-12">
                            <h3>INQUIRY NOW</h3>
                        </div>
                    </div>
                    <form action="/inquiry" method="post" id="inquiry_form">
                        <?php echo csrf_field(); ?>
                        <div class="row inquiry_form">
                            <div class="col-md-6 form-group">
                                <label class="form-label" for="company">Company Name:</label>
                                <input placeholder="Company Name" type="text" name="company" id="company"/>
                            </div>
                            <div class="col-md-6 form-group">
                                <label class="form-label" for="name">Your Name:</label>
                                <input placeholder="Your Name" type="text" name="name" id="name"/>
                            </div>  
                            <div class="col-md-6 form-group">
                                <label class="form-label" for="business">Nature of Business:</label>
                                <input placeholder="Nature of Business" type="text" name="business" id="business"/>
                            </div>   
                            <div class="col-md-6 form-group">
                                <label class="form-label" for="email">Mail ID:</label>
                                <input placeholder="Email" type="email" name="email" id="email"/>
                            </div>       
                            <div class="col-md-6 form-group">
                                <label class="form-label" for="phone">Phone No.:</label>
                                <input placeholder="Phone" type="text" name="phone" id="phone"/>
                            </div>
                            <div class="col-md-6 form-group">
                                <label class="form-label" for="state">State:</label>
                                
                                <select name="state" id="state" class="form-control">
                                    <option value="">Please select state</option>
                                    <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state => $cities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($state); ?>"><?php echo e($state); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-6 form-group">
                                <label class="form-label" for="city">City:</label>

                                <select name="city" id="city" class="form-control" disabled>
                                    <option value="">Please select city</option>
                                    <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state => $cities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option class="city-option" data-state="<?php echo e($state); ?>" value="<?php echo e($city); ?>"><?php echo e($city); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                
                            </div>
                            <div class="col-md-12 form-group">
                                <div class="terms_and_condition">
                                    <input type="checkbox" name="terms" name="terms" id="terms">
                                    <label for="terms">Terms and Condition</label>
                                    
                                </div>
                                <p class="terms_error error" style="display: none;"><b>Please accept terms and conditions.</b></p>
                            </div>

                            <div class="col-md-12 form-group form-submit">
                                <button class="bg-submit" type="submit">Submit</button>
                            </div>
                        </div>
                    </form>
                    <div class="mb-3 row">
                        
                        
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH /Users/solankiashvin/Desktop/Projects/Laravel/billwale/resources/views/includes/feature.blade.php ENDPATH**/ ?>